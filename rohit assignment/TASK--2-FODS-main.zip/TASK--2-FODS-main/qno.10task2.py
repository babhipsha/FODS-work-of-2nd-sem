# 10. Number Guessing Game: Create a program to design a number guessing game with
# the following specifications 5:
# a. The program generates a random number between 1 and 10.
# b. The player has three attempts to guess the number.
# c. If the guess is correct, display &quot;Congratulations! You won!&quot;
# d. If the guess is higher than the random number, display &quot;Too High.&quot;
# e. If the guess is lower, display &quot;Too Low.&quot;
import random

# Generate random number
number = random.randint(1, 10)

# Total attempts
attempts = 3

print("Guess the number between 1 and 10")

for i in range(attempts):
    guess = int(input("Enter your guess: "))

    if guess == number:
        print("Congratulations! You won!")
        break

    elif guess > number:
        print("Too High.")

    else:
        print("Too Low.")

# If user fails all attempts
if guess != number:
    print("Game Over! The number was", number)