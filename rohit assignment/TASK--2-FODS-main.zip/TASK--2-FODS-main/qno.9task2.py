# 9. Library Record System: Write a program to ask for the details of 3 books (Title,
# Author, ISBN, Price). Store these in a dictionary and display the information in a
# clear, well-formatted table or list. 10 marks
# Dictionary to store book details
library = {}

# Input details for 3 books
for i in range(1, 4):
    print(f"\nEnter details for Book {i}")

    title = input("Title: ")
    author = input("Author: ")
    isbn = input("ISBN: ")
    price = float(input("Price: "))

    library[title] = {
        "Author": author,
        "ISBN": isbn,
        "Price": price
    }

# Display records
print("\nLibrary Records")
print("-" * 40)

for title, details in library.items():
    print("Title :", title)
    print("Author:", details["Author"])
    print("ISBN  :", details["ISBN"])
    print("Price :", details["Price"])
    print("-" * 40)