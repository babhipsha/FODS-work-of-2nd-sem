# 3. Palindrome Checker: Write a program to create a function that accepts one string as
# input and checks whether it is a palindrome (reads the same forwards and backwards)
# or not. 10 marks
# Function to check palindrome

def palindrome_check(text):
    if text == text[::-1]:
        return "Palindrome"
    else:
        return "Not a Palindrome"

# User input
word = input("Enter a string: ")

# Function call
print(palindrome_check(word))