# 2. Geometry Calculator: Write a program to implement separate functions for the
# following calculations. Each function should take necessary user inputs (like radius or
# side length) as parameters and return the result. 10 marks
# a. Area of a Circle
# b. Perimeter of a Square
# c. Area of a Triangle
# d. Volume of a Cube
import math

# Area of Circle
def area_circle(radius):
    return math.pi * radius * radius

# Perimeter of Square
def perimeter_square(side):
    return 4 * side

# Area of Triangle
def area_triangle(base, height):
    return 0.5 * base * height

# Volume of Cube
def volume_cube(side):
    return side ** 3

# User input
r = float(input("Enter radius of circle: "))
s = float(input("Enter side of square/cube: "))
b = float(input("Enter base of triangle: "))
h = float(input("Enter height of triangle: "))

# Display results
print("Area of Circle =", area_circle(r))
print("Perimeter of Square =", perimeter_square(s))
print("Area of Triangle =", area_triangle(b, h))
print("Volume of Cube =", volume_cube(s))