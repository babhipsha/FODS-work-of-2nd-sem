# 7. Vowel Counter: Write a function count_vowels(text) that takes a string as input and
# returns a dictionary showing how many times each vowel (a, e, i, o, u) appears,
# ignoring case. 10 marks
# Function to count vowels

def count_vowels(text):
    vowels = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}

    for char in text.lower():
        if char in vowels:
            vowels[char] += 1

    return vowels

# User input
sentence = input("Enter text: ")

# Function call
print(count_vowels(sentence))