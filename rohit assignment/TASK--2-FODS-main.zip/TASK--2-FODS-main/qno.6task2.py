# 6. Search and Identify: Write a function that accepts two parameters: a list of fruit
# names and a specific fruit to search for. The function should return the index of the
# fruit if found; otherwise, it should return &quot;Item not in list.&quot; 10 marks
# Function to search fruit in list

def search_fruit(fruits, item):
    if item in fruits:
        return fruits.index(item)
    else:
        return "Item not in list."

# Fruit list
fruit_list = ["apple", "banana", "orange", "mango"]

# User input
search_item = input("Enter fruit to search: ")

# Function call
print(search_fruit(fruit_list, search_item))