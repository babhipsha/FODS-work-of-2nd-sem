# 1. Arithmetic Operations Function: Write a program to create a function that accepts
# two numbers and displays their result for addition, subtraction, and multiplication. 10
# marks
def arithmetic_operations(num1, num2):
    print("Addition =", num1 + num2)
    print("Subtraction =", num1 - num2)
    print("Multiplication =", num1 * num2)

# User input
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

# Function call
arithmetic_operations(a, b)