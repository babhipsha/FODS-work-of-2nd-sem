# 4. Word Frequency Counter: Write a function that takes a list of words as input and
# returns a dictionary showing the frequency of each word. Test this with a list
# containing at least five words, some of which should repeat. 10 marks

# Function to count word frequency

def word_frequency(words):
    frequency = {}

    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1

    return frequency

# Test list
word_list = ["apple", "banana", "apple", "orange", "banana", "apple"]

# Function call
print(word_frequency(word_list))