# 5. Grade Sorter: Write a function that accepts a list of student grades (integers) and
# returns the grades sorted in descending order. 10 marks
# Function to sort grades in descending order

def sort_grades(grades):
    return sorted(grades, reverse=True)

# User input
grades = [78, 45, 90, 67, 88]

# Function call
print("Sorted Grades:", sort_grades(grades))