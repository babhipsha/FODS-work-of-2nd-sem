# 8. Unique Element Merger: Write a program to accept two different lists of numbers
# from the user. Return a new list that contains only the unique elements from both lists
# combined, sorted in ascending order. 10 marks
# Input lists from user
list1 = list(map(int, input("Enter first list numbers separated by space: ").split()))
list2 = list(map(int, input("Enter second list numbers separated by space: ").split()))

# Merge unique elements and sort
unique_list = sorted(list(set(list1 + list2)))

# Display result
print("Unique Sorted List:", unique_list)
